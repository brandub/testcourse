#import <Foundation/Foundation.h>

/**
 Key used for constructing errors when spoken instructions fail.
 */
extern const NSErrorUserInfoKey MBSpokenInstructionErrorCodeKey;
